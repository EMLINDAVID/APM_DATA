package ust.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import ust.base.AndroidActions;

public class Formpage extends AndroidActions{

	
	public Formpage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		
	}
	
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"Enter name here\")")
	private WebElement nameField;
	
	@AndroidFindBy(xpath="//android.widget.RadioButton[@text='Female']")
	private WebElement femaleOption;
	
	@AndroidFindBy(xpath="//android.widget.RadioButton[@text='Male']")
	private WebElement maleOption;
	
	@AndroidFindBy(id = "android:id/text1")
	private WebElement countrySelection;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement shopButton;
	
	
	@AndroidFindBy(xpath="//android.widget.RelativeLayout[2]//android.widget.LinearLayout//android.widget.LinearLayout[2]")
	private WebElement shoe;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/appbar_btn_cart")
	private WebElement cart;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"$ 120.0\")")
	private WebElement rate;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"General Store\")")
	private WebElement title;
	
//	@AndroidFindBy(id="com.androidsample.generalstore:id/toolbar_title")
//	private WebElement title;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"Products\")")
	private WebElement prodtitle;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"Cart\")")
	private WebElement carttitle;
	
	public void setNameField(String name)
	{
		nameField.sendKeys(name);
		driver.hideKeyboard();
		
	}

	
	public void setGender(String gender)
	{	
		if (gender.contains("female"))
			femaleOption.click();
		else
			maleOption.click();
			
	}
	
	public void setCountrySelection(String countryName)
	
	{
		countrySelection.click();
		scrollToText(countryName);
		driver.findElement(By.xpath("//android.widget.TextView[@text='"+countryName+"']")).click();
		
	}
	
	public void shopBtnClick() {
		shopButton.click();
	}
	
	public void shoeClick() {
		shoe.click();
	}
	public void cartClick() {
		cart.click();
	}
	
	public String getTitle() {
		return title.getText();
		}
	
	public String getTitleprod() {
		return prodtitle.getText();
		}
	
	public String getTitlecart() {
		return carttitle.getText();
		}
}
