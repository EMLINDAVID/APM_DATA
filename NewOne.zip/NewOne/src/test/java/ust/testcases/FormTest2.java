package ust.testcases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.appium.java_client.AppiumBy;
import ust.base.Basetest1;
import ust.pages.Formpage;

@Listeners(ust.util.SampleListener.class)
public class FormTest2 extends Basetest1 {

	@DataProvider(name = "logData1")
	public Object[][] getData() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\TestData\\form.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("name");
	testData[i][1] = row.get("gender");
	testData[i][2] = row.get("country");
	}
	return testData;
	}

	@Test(priority=1,dataProvider="logData1")
	public void test1(String name,String gender,String countryName) {
		Formpage f1=new Formpage(driver);
		
       String t1=f1.getTitle();
		SoftAssert softassert=new SoftAssert();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(t1.equalsIgnoreCase("General Store"));
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).isDisplayed());
						
			});
		
		f1.setNameField(name);
		f1.setGender(gender);
		f1.setCountrySelection(countryName);
		f1.shopBtnClick();
		
		String t2=f1.getTitleprod();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(t2.equalsIgnoreCase("Products"));
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).isDisplayed());
						
			});
		
		f1.shoeClick();
		f1.cartClick();
		
		
		String t3=f1.getTitlecart();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(t3.equalsIgnoreCase("Cart"));
			});
		
		String price="$120.0";
		softassert.assertEquals(driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"$120.0\")")).getText()
		.equalsIgnoreCase(price), true);
		
}}

