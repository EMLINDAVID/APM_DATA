package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;

public class ExtendReportManager extends AndroidActions{

	public ExtendReportManager(AndroidDriver driver) {
		super(driver);
	}
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent=new ExtentReports();
		String repName="TestReport-"+AndroidActions.timestamp+".html";
		spark=new ExtentSparkReporter(System.getProperty("user.dir")
				+"/TestOutput/"+repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment","Production");
		extent.setSystemInfo("User Name","Emlin");
		spark.config().setDocumentTitle("APM Contacts Report");
		//Name of the report
		spark.config().setReportName("Contact Report");
		//Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}

}
