package base;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import utilities.Dateutils;

public class AndroidActions {
	public static  AndroidDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = Dateutils.getTimeStamp();
	
	public AndroidActions(AndroidDriver driver)
	{
	
		this.driver = driver;
	}

	
	public static void takeScreenShot(String filePath) {
		try {
			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
