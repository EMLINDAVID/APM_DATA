package testcase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.BaseTest_contact;
import io.appium.java_client.AppiumBy;
import pageFactory.ContactForm;

@Listeners(utilities.SampleListener.class)
public class Contact_Testcase  extends BaseTest_contact{
	@DataProvider(name = "DataInput")
	public Object[][] getData() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\contact.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("firstname");
	testData[i][1] = row.get("lastname");
	testData[i][2] = row.get("phone");
	}
	return testData;
	}
	
	@DataProvider(name = "messageDataInput")
	public Object[][] getData1() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\message.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("message1");
	testData[i][1] = row.get("message2");
	testData[i][2] = row.get("message3");
	}
	return testData;
	}

	
	@Test(priority=1,dataProvider="DataInput")
	public void contact_testcase(String firstname,String lastname,String phone) {
		ContactForm c= new ContactForm(driver);
		SoftAssert softassert=new SoftAssert();
		String message="Contacts";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.google.android.contacts:id/product_name")).getText()
		.equalsIgnoreCase(message), true);
		
		String message2="Skip";
		softassert.assertEquals(driver.findElement(AppiumBy.id("android:id/button2")).getText()
		.equalsIgnoreCase(message2), true);
		
		c.skipclick();
		
		String allowmsg="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_allow_button")).getText()
		.equalsIgnoreCase(allowmsg), true);
		
		String disallowmsg="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_deny_button")).getText()
		.equalsIgnoreCase(disallowmsg), true);
		
		String contactpresent="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_deny_button")).getText()
		.equalsIgnoreCase(disallowmsg), true);
		
		c.allowclick();
		c.addcontactclick();
		c.firstnameinput(firstname);
		c.lasttnameinput(lastname);
		c.phonenumberinput(phone);
		c.saveiconclick();
	}	
		@Test(priority=2,dataProvider="messageDataInput")
		public void message_testcase(String message1,String message2,String message3) {	
	    ContactForm c= new ContactForm(driver);
		c.messageiconclick();
		c.messageboxclick1();
		c.messagetextsent(message1);
		c.messageboxclick();
		c.messagetextsent(message2);
		c.messageboxclick();
		c.messagetextsent(message3);
		c.messageboxclick();
		c.backclick();
		
	}
	
	

}
